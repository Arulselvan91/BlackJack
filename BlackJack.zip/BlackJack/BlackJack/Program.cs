﻿using System;
using System.Collections.Generic;
using BlackJack;
using CardGameFramework;

namespace BlackJackConsoleClient
{
    class Program
    {
        static void Main(string[] args)
        {
            BlackJackPlayer player=new BlackJackPlayer();
            BlackJackPlayer dealer=new BlackJackPlayer();
            Deck deck=new Deck();
            //Applying a Singleton Design Pattern
            BlackJackGame game = BlackJackGame.BlackJackGameInstance(player,dealer,deck);
            //Starting a new game
            game.DealNewGame();
            //Get the sum of hand (Dealer) and validate against game rules
            if (game.Dealer.Hand.NumberOfCards == 2 && game.Dealer.HasBlackJack())
            {
                Console.WriteLine("Dealer has BlackJack");
            }
            else if (game.Dealer.IsBusted())
            {
                Console.WriteLine("Dealer has busted");
            }
            Console.WriteLine("Player:Sum of Cards");
            Console.WriteLine(game.CurrentPlayer.Hand.GetSumOfCards().ToString());
            //Display cards in player hand
            Console.WriteLine("Player Cards");
            List<Card> pcards = game.CurrentPlayer.Hand.Cards;
            foreach (Card t in pcards)
            {
                Console.WriteLine(t.FaceValue);
            }
            Console.WriteLine("Dealer Cards");
            List<Card> dcards = game.Dealer.Hand.Cards;
            foreach (Card t in dcards)
            {
                //if not played by dealer
                if (t.FaceUp == true)
                    Console.WriteLine(t.FaceValue);
            }
            Console.WriteLine("Would you like to Hit Y/N ?");
            string userChoice = Console.ReadLine();            
            if (userChoice == "Y" || userChoice == "y")
            {
                game.CurrentPlayer.Hit();
            }
            else
            {
                game.DealerPlay();
            }

            //Get sum of hand (Player)
            Console.WriteLine("Player:Sum of Cards");
            Console.WriteLine(game.CurrentPlayer.Hand.GetSumOfCards().ToString());
            Console.WriteLine("Player Cards");
            pcards = game.CurrentPlayer.Hand.Cards;
            foreach (Card t in pcards)
            {
                Console.WriteLine(t.FaceValue);
            }
            Console.WriteLine("Dealer:Sum of Cards");
            Console.WriteLine(game.Dealer.Hand.GetSumOfCards().ToString());
            Console.WriteLine("Dealer Cards");
            dcards = game.Dealer.Hand.Cards;
            foreach (Card t in dcards)
            {
                //if not played by dealer
                if (t.FaceUp == true)
                    Console.WriteLine(t.FaceValue);
            }
            // Validate against the game rules and declare the result
            if (game.Dealer.Hand.NumberOfCards == 2 && game.Dealer.HasBlackJack())
            {
                Console.WriteLine("Dealer has BlackJack");
            }
            else if (game.Dealer.IsBusted())
            {
                Console.WriteLine("Dealer has busted");
            }
            else if (game.Dealer.Hand.CompareFaceValue(game.CurrentPlayer.Hand) > 0)
            {
                Console.WriteLine("Dealer has Won");
            }

            else if (game.CurrentPlayer.IsBusted())
            {
                Console.WriteLine("Player has busted");
            }
            else
            {
                Console.WriteLine("Player has Won");
            }
            Console.ReadLine();
        }
    }
}
