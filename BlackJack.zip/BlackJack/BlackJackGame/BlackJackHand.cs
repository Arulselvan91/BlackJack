﻿using System;
using CardGameFramework;

namespace BlackJack
{
    public class BlackJackHand : Hand
    {
        /// <summary>
        /// Compares the sum of face values of cards in dealer/player hands
        /// </summary>
        /// <returns>Retrun -1, 0, 1 based on the comparision</returns>
        public int CompareFaceValue(object otherHand)
        {
            BlackJackHand aHand = otherHand as BlackJackHand;
            if (aHand != null)
            {
                return this.GetSumOfCards().CompareTo(aHand.GetSumOfCards());
            }
            return 0;
        }

        /// <summary>
        /// Calculate the sum of face values of cards in hand
        /// </summary>
        /// <returns>Retrun the sum of face values of cards in hand</returns>
        public int GetSumOfCards()
        {
            int value = 0;
            int numberOfAces = 0;

            foreach (var c in _cards)
            {
                switch (c.FaceValue)
                {
                    case "Ace":
                        numberOfAces++;
                        value += 11;
                        break;
                    case "King":
                    case "Queen":
                    case "Jack":
                        value += 10;
                        break;
                    default:
                        value += Convert.ToInt16(c.FaceValue);
                        break;
                }
            }
            while (value > 21 && numberOfAces > 0)
            {
                value -= 10;
                numberOfAces--;
            }
            return value;
        }
    }
}
