﻿using CardGameFramework;

namespace BlackJack
{
    public class BlackJackGame : CardGame
    {
        private BlackJackPlayer _dealer;
        private BlackJackPlayer _player;
        //Implemention of Singleton Pattern
        private static BlackJackGame _blackJackGameInstance;
        public static BlackJackGame BlackJackGameInstance(BlackJackPlayer player, BlackJackPlayer dealer, Deck deck)
        {
            if (_blackJackGameInstance == null)
            {
                _blackJackGameInstance = new BlackJackGame(player, dealer, deck);
            }
            return _blackJackGameInstance;
        }
        private BlackJackGame()
        {
        }
        private BlackJackGame(BlackJackPlayer player, BlackJackPlayer dealer, Deck deck)
        {
            _dealer = dealer;
            _player = player;
            _deck = deck;
        }
        public BlackJackPlayer CurrentPlayer { get { return _player; } }
        public BlackJackPlayer Dealer { get { return _dealer; } }
        /// <summary>
        /// Start a new game
        /// </summary>
        public void DealNewGame()
        {
            _deck.Shuffle();
            _player.NewHand();
            _dealer.NewHand();
            for (int i = 0; i < 2; i++)
            {
                Card c = _deck.DrawCard();
                _player.Hand.Cards.Add(c);
                Card d = _deck.DrawCard();
                if (i == 1)
                    d.FaceUp = false;
                _dealer.Hand.Cards.Add(d);
            }
            _player.CurrentDeck = _deck;
            _dealer.CurrentDeck = _deck;
        }
        /// <summary>
        /// Dealer to continue to play the game
        /// </summary>
        public void DealerPlay()
        {
            _dealer.Hand.Cards[1].FaceUp = true;
            if (_dealer.Hand.GetSumOfCards() < 17)
            {
                _dealer.Hit();
                DealerPlay();
            }
        }
    }
}
