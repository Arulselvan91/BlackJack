﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CardGameFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CardGameFramework.Tests
{
    [TestClass()]
    public class CardTestCard
    {
        [TestMethod()]
        public void CardTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void CardTest1()
        {
            Assert.Fail();
        }
    }
}