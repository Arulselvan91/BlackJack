﻿namespace CardGameFramework
{
    //Card is a primary entity in any card game
    public class Card
    {
        //Set of information about card
        public static readonly string[] SuitSet = new string[4] { "Spade", "Diamond", "Heart", "Club" };
        public static readonly string[] CardFaceValues = new string[13] { "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "King", "Queen", "Jack" };
        //Suit information spade, diamond etc.
        public string Suit { get; set; }
        //Face value of the card 1, 2, Ace etc.
        public string FaceValue { get; set; }
        //Card state: up or down
        public bool FaceUp { get; set; }
        //Constructor for Card class
        public Card(string suit, string faceValue, bool faceUp)
        {
            Suit = suit;
            FaceValue = faceValue;
            FaceUp = faceUp;
        }
    }

}
